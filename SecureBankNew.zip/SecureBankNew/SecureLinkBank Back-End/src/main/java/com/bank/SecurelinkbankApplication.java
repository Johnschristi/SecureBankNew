package com.bank;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication                                               
public class SecurelinkbankApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurelinkbankApplication.class, args);
		System.out.println("Welcome to Securelink Bank");
	}

}
